from gui.mainwindow import MainWindow
from tkinter import *
from tkinter.ttk import *

root = Tk()

MainWindow(root)

root.mainloop()
