from tkinter import *
from tkinter.ttk import *
from lib.commanager import commanager

comm = commanager()
